from .search import search_blueprint
from .homepage import homepage_blueprint
from .auth import auth_blueprint
from .profile import profile_blueprint
from .add_comment import add_comment_blueprint